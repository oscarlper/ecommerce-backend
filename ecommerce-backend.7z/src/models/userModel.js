import mongoose from 'mongoose';
 
export default mongoose.model('Users',{
    email: String,
    password: String,
    firstName: String,
    lastName: String,
    telephone: String,
    isAdmin: Boolean,
    userPic: String
});
