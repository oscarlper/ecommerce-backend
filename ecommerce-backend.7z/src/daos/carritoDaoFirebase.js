import ContenedorFirebase from "../containers/containerFirebase.js";

class CarritoDaoFirebase extends ContenedorFirebase {
  constructor() {
    super("carritos");
  }
}

export default CarritoDaoFirebase;